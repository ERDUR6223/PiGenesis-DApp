# PiGenesis DApp
NFT görev sistemi ile Pi Network için geliştirilmiş bir Web3 uygulamasıdır.